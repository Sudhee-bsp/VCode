<?php

include('./server.php');


$quesTest = "";

$query4 = "SELECT question, question_number FROM questions ORDER BY question_number DESC";
$result4 = mysqli_query($conn, $query4);

// if ($result4){
//     echo "<br> <br> Previous questions fetched successfully!";
// }
// else{
//     die("Sorry we failed to insert: ". mysqli_error($conn));
// }






// if ($result5){
//     echo "<br> <br> Previous results fetched successfully!";
// }
// else{
//     die("Sorry we failed to insert: ". mysqli_error($conn));
// }



?>

<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>V-Quiz</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <!-- Custom CSS -->
        <link href="style.css" rel="stylesheet">
    </head>
    <body>
    <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" style="background-color:white;">
                        <span class="icon-bar" style="background-color:black;"></span>
                        <span class="icon-bar " style="background-color:black;"></span>
                        <span class="icon-bar" style="background-color:black;"></span>                        
                    </button>
                    <a class="navbar-brand" href="" >V-Quiz</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li><button class="btn b1" style="margin-top:5px;margin-right:10px;">Home</button></li>
                        <li><button  class="btn b1" style="margin-top:5px;">Logout</button></li>
                    </ul>
                </div>
            </div>
        </div>
        <hr style="border-top:1px dashed black;">
            

        <div class="container">
            <br>  
            <br>
            <?php while($row1 = mysqli_fetch_array($result4)){ 
                $que_num = $row1['question_number']; ?>
                <h2>Question: <?php echo $row1['question_number']; ?></h2>
                <textarea rows="8.5" class="form-control" readonly> <?php echo $row1['question'];?></textarea>
                <div class="container-fluid">
                    <?php $query5 = "SELECT  question_number, first, second, third, fourth, fifth FROM winners WHERE question_number= '$que_num' ";
                    $result5 = mysqli_query($conn, $query5);
                    ?>
                    <div class="col-sm-12" style="display: flex;">
                    <div col-sm-4>
                       
                        <div class="download">
                            <?php $que=$row1['question_number'];?>
                            <h3>To Download Solution:-</h3>
                            <a  class="btn b2" style="margin-top:5px;margin-right:10px;" href="download.php?id=<?php echo $row1['question_number'] ?>">C</a>
                            <a  class="btn b2" style="margin-top:5px;">Java</a>
                            <a  class="btn b2" style="margin-top:5px;">Python</a>
                        </div>
                        
                        <br>
                    </div>
                    <?php
                    
                    while ($row2 = mysqli_fetch_array($result5)) {
                        $first = $row2['first'];
                        $second = $row2['second'];
                        $third = $row2['third'];
                        $fourth = $row2['fourth'];
                        $fifth = $row2['fifth']; ?>
                        <div class="col-sm-3 col-sm-offset-1" style="margin:20px;background-color:#E4DED7;height:250px;border-radius:5px;">
                        <p style="display:inline;"><h3>Results for Question Number: <?php echo $row2['question_number'] ?></h3></p>
                            <p>1.) <?php echo $first; ?></p>
                            <p>2.) <?php echo $second; ?> </p>
                            <p>3.) <?php echo $third; ?></p>
                            <p>4.) <?php echo $fourth; ?></p>
                            <p>5.) <?php echo $fifth; ?></p>
                        </div>
                    </div> 
                    <?php } ?>
                </div>
                <br>
                <br>
                <?php 
            }   ?>
            
        </div>

    </body>
</html>