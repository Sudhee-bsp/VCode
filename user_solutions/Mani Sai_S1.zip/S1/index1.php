<?php
include('./server.php');

if(!isset($_SESSION)){
    session_start();
  }
?>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>V-Quiz</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <!-- Custom CSS -->
        <link href="style.css" rel="stylesheet">
    </head>
    <body>
        <div class="navbar navbar-inverse navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar" style="background-color:white;">
                        <span class="icon-bar" style="background-color:black;"></span>
                        <span class="icon-bar " style="background-color:black;"></span>
                        <span class="icon-bar" style="background-color:black;"></span>                        
                    </button>
                    <a class="navbar-brand" href="" >V-Quiz</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li><button class="btn b1" style="margin-top:5px;margin-right:10px;">Home</button></li>
                        <li><button  class="btn b1" style="margin-top:5px;">Logout</button></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-sm-12 above">
            
            
            <div style="display:inline;">
                <h2>Today Quiz Question:</h2>
                <p>Ends at</p>
            </div>
            <div class="current">
            <form>
            <textarea rows="8.5" class="form-control" readonly><?php
                    $query= "SELECT * FROM questions ORDER BY question_number DESC LIMIT 1";
                    $result = mysqli_query($conn, $query)or die(mysqli_error($conn));
                    while($row=mysqli_fetch_array($result)){
                        echo $row['question'];
                    }
                ?></textarea>
            </form>
            </div>
        </div>
        <div class="container">
            <div class="col-sm-12" style="display: flex;">
                <div col-sm-4>
                    <div class="upload">
                        <h3> To Upload your Solution:-</h3>
                            <a  class="btn b2" style="margin-top:5px;margin-right:10px;width:280px;"><input type="file" id="myfile" name="myfile"></a>
                            <a  class="btn b2" style="margin-top:5px;">Upload</a>
                    </div>
                    <div class="download">
                        <h3>To Download Solution:-</h3>
                        <a class="btn b2" style="margin-top:5px;margin-right:10px;">C</a>
                        <a  class="btn b2" style="margin-top:5px;">Java</a>
                        <a  class="btn b2" style="margin-top:5px;">Python</a>
                    </div>
                </div>
                <div class="col-sm-4" style="background-color:white;height:auto;">
                    <h3>Note:-</h3>
                        <p>1.) Last date to upload file today night 11:59 p.m.</p>
                        <p>2.) There will be the winner for every quiz</p>
                        <p>3.) Save file in .c/.java/.py </p>
                </div>
                <div class="col-sm-4" style="background-color:#E4DED7;height:250px;border-radius:5px;">
                    <p style="display:inline;"><h3>Results</h3><p>22/03/2020</p></p>
                        <p>1.) </p>
                        <p>2.) </p>
                        <p>3.) </p>
                        <p>4.) </p>
                        <p>5.) </p>
                </div>
            </div>
        </div>
        <hr style="border-top:1px dashed black;">
        <div class="col-sm-10 col-sm-offset-1">
        <form action="user_previous.php" method="POST">
        <center><button type="submit" style="background-color:#E4DED7;margin-top:10px;border-radius:25px;width:80%;"><center><h4>Click here to see all Previous Questions</h4></center></button></center>

        </form>   
    
    </body>
</html>
