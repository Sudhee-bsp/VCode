<?php
include('./server.php');

if(!isset($_SESSION)){
    session_start();
  }
?>

<body>
    <h1>WELCoME
    <?php 
    $name=$_SESSION['name'];
    echo $name;
    ?>


    </h1>
</body>